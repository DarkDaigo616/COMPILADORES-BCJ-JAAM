# Hands-on 2: Lexical Analysis with FSA

**Compiladores — CUCEI, Universidad de Guadalajara**
**Semestre 2026A**

---

## Descripción

Implementación orientada a objetos en **C++17** de un **Autómata de Estado Finito (FSA)** que reconoce y clasifica *cifras numéricas* como tokens léxicos. Cubre los tres subtipos:

| Tipo | Ejemplos |
|------|---------|
| `INTEGER` | `0`, `42`, `-7`, `+100` |
| `DECIMAL` | `3.14`, `-0.5`, `+2.71828` |
| `SCIENTIFIC` | `1e10`, `2.5E-3`, `-3e+4`, `6.022e23` |

---

## Diagrama de Transiciones

```
  Alfabeto de entrada
  ┌────────┬──────────────────────────────┐
  │ Clase  │ Símbolos                     │
  ├────────┼──────────────────────────────┤
  │ SIGN   │ + –                          │
  │ DIGIT  │ 0 1 2 3 4 5 6 7 8 9         │
  │ DOT    │ .                            │
  │ EXP    │ e E                          │
  │ OTHER  │ cualquier otro (→ DEAD)      │
  └────────┴──────────────────────────────┘

  Estados (* = aceptación):

       SIGN        DIGIT
  q0 ──────► q1 ──────► q2 *
  │                      │  │
  └─────────────────────►┘  │ DIGIT (bucle)
                            │
                       DOT  │         EXP
                 q3 ◄───────┘    q5 ◄──────
                  │               │
            DIGIT │         SIGN  │  DIGIT
                  ▼          q6 ◄─┘    │
                 q4 *               q7 *◄─┘ (bucle)
                  │
             EXP  └──────────────► q5


  Tabla de transiciones:
  ┌────────┬───────┬───────┬───────┬───────┬───────┐
  │ Estado │ SIGN  │ DIGIT │  DOT  │  EXP  │ OTHER │
  ├────────┼───────┼───────┼───────┼───────┼───────┤
  │  q0    │  q1   │  q2   │ DEAD  │ DEAD  │ DEAD  │
  │  q1    │ DEAD  │  q2   │ DEAD  │ DEAD  │ DEAD  │
  │  q2 *  │ DEAD  │  q2   │  q3   │  q5   │ DEAD  │
  │  q3    │ DEAD  │  q4   │ DEAD  │ DEAD  │ DEAD  │
  │  q4 *  │ DEAD  │  q4   │ DEAD  │  q5   │ DEAD  │
  │  q5    │  q6   │  q7   │ DEAD  │ DEAD  │ DEAD  │
  │  q6    │ DEAD  │  q7   │ DEAD  │ DEAD  │ DEAD  │
  │  q7 *  │ DEAD  │  q7   │ DEAD  │ DEAD  │ DEAD  │
  └────────┴───────┴───────┴───────┴───────┴───────┘

  Lenguaje aceptado (expresión regular equivalente):
    [+-]?  [0-9]+  ( '.'  [0-9]+  ( [eE] [+-]? [0-9]+ )? )?
  | [+-]?  [0-9]+               [eE] [+-]? [0-9]+
```

---

## Estructura del Proyecto

```
Hands-on_2_Lexical_Analysis_with_FSA/
├── Makefile
├── README.md
└── src/
    ├── FSA.h              ← Definición del autómata (estados, tabla, δ)
    ├── FSA.cpp            ← Implementación: validate(), trace(), step()
    ├── Token.h            ← Clase Token (tipo + lexema)
    ├── LexicalAnalyzer.h  ← Scanner que usa el FSA
    ├── LexicalAnalyzer.cpp
    └── main.cpp           ← Driver: suite de tests + trazas + modo interactivo
```

---

## Diseño OO

```
┌────────────────────────────────────────────────────┐
│  <<enum class>>  State                             │
│  Q0 Q1 Q2 Q3 Q4 Q5 Q6 Q7 DEAD                    │
└────────────────────────────────────────────────────┘
┌────────────────────────────────────────────────────┐
│  <<enum class>>  CharClass                         │
│  SIGN  DIGIT  DOT  EXP  OTHER                     │
└────────────────────────────────────────────────────┘
┌────────────────────────────────────────────────────┐
│  class FSA                                         │
├────────────────────────────────────────────────────┤
│  – _table : unordered_map<(State,CharClass),State> │
│  – _acceptStates : set<State>                      │
│  – _startState : State                             │
├────────────────────────────────────────────────────┤
│  + validate(token) : bool                          │
│  + trace(token) : vector<string>                   │
│  – step(state, char) : State                       │
│  – classify(char) : CharClass              [static]│
│  + stateName(State) : string               [static]│
└────────────────────────────────────────────────────┘
┌────────────────────────────────────────────────────┐
│  class Token                                       │
├────────────────────────────────────────────────────┤
│  – _type : TokenType                               │
│  – _lexeme : string                                │
├────────────────────────────────────────────────────┤
│  + type() / lexeme() : getters                     │
│  + print()                                         │
│  + typeName(TokenType) : string            [static]│
└────────────────────────────────────────────────────┘
┌────────────────────────────────────────────────────┐
│  class LexicalAnalyzer                             │
├────────────────────────────────────────────────────┤
│  – _fsa : FSA                                      │
├────────────────────────────────────────────────────┤
│  + classify(lexeme) : Token                        │
│  + scan(input) : vector<Token>                     │
│  + printTrace(lexeme)                              │
└────────────────────────────────────────────────────┘
```

---

## Compilar y ejecutar

### Requisitos
- **g++** con soporte C++17  (`g++ --version`)
- **make**

### Comandos

```bash
# Compilar
make

# Ejecutar suite de tests + trazas + modo interactivo
./fsa_lexer

# Clasificar tokens desde línea de comandos
./fsa_lexer 42 -3.14 2.5E-3 abc

# Limpiar binario
make clean
```

### Salida esperada (extracto)

```
Lexeme         Expected    Got         Token Type    Result
------------------------------------------------------------
"42"           VALID       VALID       INTEGER       ✓ PASS
"-3.14"        VALID       VALID       DECIMAL       ✓ PASS
"2.5E-3"       VALID       VALID       SCIENTIFIC    ✓ PASS
"abc"          INVALID     INVALID     UNKNOWN       ✓ PASS
Results: 24 passed, 0 failed (24 total)
```

**Traza FSA para `2.5E-3`:**
```
  δ(q0 (start), '2') → q2 (integer) *
  δ(q2 (integer) *, '.') → q3 (after dot)
  δ(q3 (after dot), '5') → q4 (decimal) *
  δ(q4 (decimal) *, 'E') → q5 (after e/E)
  δ(q5 (after e/E), '-') → q6 (exp sign)
  δ(q6 (exp sign), '3') → q7 (exponent) *
  ✓  ACCEPTED
```

---

## Conceptos clave

| Concepto | Rol en este proyecto |
|----------|---------------------|
| **FSA / DFA** | Autómata determinista que consume carácter a carácter |
| **Estado** | Enum `State` (q0–q7, DEAD) |
| **Función de transición δ** | `unordered_map` indexado por `(State, CharClass)` |
| **Estado de aceptación** | `std::set<State>` con q2, q4, q7 |
| **Token** | Par `(TokenType, lexema)` producido al aceptar |
| **Analizador Léxico** | Usa el FSA para clasificar strings en tokens |

---

## Autor

**[Tu nombre]**  
Compiladores — CUCEI, Universidad de Guadalajara  
Semestre 2026A
