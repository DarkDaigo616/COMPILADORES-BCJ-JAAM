/**
 * @file main.cpp
 * @brief Demo and test driver for the FSA-based Lexical Analyzer.
 *
 *  Usage:
 *    ./fsa_lexer             → runs built-in test suite
 *    ./fsa_lexer <token>...  → classifies each argument
 *
 * Compiladores — CUCEI UdeG  |  Hands-on 2: Lexical Analysis with FSA
 */

#include "LexicalAnalyzer.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>

// ─── Helpers ──────────────────────────────────────────────────────────────────
static void printBanner(const std::string& title) {
    const int W = 60;
    std::string bar(W, '=');
    std::cout << "\n" << bar << "\n";
    std::cout << "  " << title << "\n";
    std::cout << bar << "\n";
}

static void runTestSuite(LexicalAnalyzer& la) {
    // { input, expected_valid }
    struct TestCase { std::string input; bool expectedValid; };

    std::vector<TestCase> cases = {
        // ── Valid integers ────────────────────────────────────
        {"0",          true},
        {"42",         true},
        {"-7",         true},
        {"+100",       true},
        {"9999",       true},

        // ── Valid decimals ────────────────────────────────────
        {"3.14",       true},
        {"-0.5",       true},
        {"+2.71828",   true},
        {"0.0",        true},

        // ── Valid scientific notation ─────────────────────────
        {"1e10",       true},
        {"2.5E-3",     true},
        {"-3e+4",      true},
        {"1.0E+100",   true},
        {"6.022e23",   true},

        // ── Invalid cases ─────────────────────────────────────
        {"",           false},  // empty
        {".",          false},  // lone dot
        {"1.",         false},  // dot without fraction digit
        {"e5",         false},  // starts with exponent marker
        {"1e",         false},  // exponent with no digits
        {"--3",        false},  // double sign
        {"12.34.56",   false},  // two dots
        {"abc",        false},  // letters
        {"1 2",        false},  // space (treated as one token)
        {"3e2.1",      false},  // dot in exponent
    };

    printBanner("Automated Test Suite");
    int passed = 0, failed = 0;

    std::cout << std::left
              << std::setw(15) << "Lexeme"
              << std::setw(12) << "Expected"
              << std::setw(12) << "Got"
              << std::setw(14) << "Token Type"
              << "Result\n";
    std::cout << std::string(60, '-') << "\n";

    for (auto& tc : cases) {
        Token tok = la.classify(tc.input);
        bool valid = (tok.type() != TokenType::UNKNOWN);
        bool ok    = (valid == tc.expectedValid);
        if (ok) ++passed; else ++failed;

        std::cout << std::setw(15) << ("\"" + tc.input + "\"")
                  << std::setw(12) << (tc.expectedValid ? "VALID" : "INVALID")
                  << std::setw(12) << (valid            ? "VALID" : "INVALID")
                  << std::setw(14) << Token::typeName(tok.type())
                  << (ok ? "✓ PASS" : "✗ FAIL") << "\n";
    }

    std::cout << std::string(60, '-') << "\n";
    std::cout << "Results: " << passed << " passed, " << failed << " failed"
              << " (" << cases.size() << " total)\n";
}

static void showTransitionDiagram() {
    printBanner("FSA Transition Diagram — Numeric Literals");
    std::cout << R"(
  States (* = accept):
    q0  Start state
    q1  After optional sign (+ / -)
    q2* Integer digits
    q3  After decimal point '.'
    q4* Decimal fraction digits
    q5  After exponent marker (e / E)
    q6  After exponent sign
    q7* Exponent digits

  Transition Table:
  ┌────────┬───────┬───────┬───────┬───────┬───────┐
  │ State  │ SIGN  │ DIGIT │  DOT  │  EXP  │ OTHER │
  ├────────┼───────┼───────┼───────┼───────┼───────┤
  │  q0    │  q1   │  q2   │ DEAD  │ DEAD  │ DEAD  │
  │  q1    │ DEAD  │  q2   │ DEAD  │ DEAD  │ DEAD  │
  │  q2 *  │ DEAD  │  q2   │  q3   │  q5   │ DEAD  │
  │  q3    │ DEAD  │  q4   │ DEAD  │ DEAD  │ DEAD  │
  │  q4 *  │ DEAD  │  q4   │ DEAD  │  q5   │ DEAD  │
  │  q5    │  q6   │  q7   │ DEAD  │ DEAD  │ DEAD  │
  │  q6    │ DEAD  │  q7   │ DEAD  │ DEAD  │ DEAD  │
  │  q7 *  │ DEAD  │  q7   │ DEAD  │ DEAD  │ DEAD  │
  └────────┴───────┴───────┴───────┴───────┴───────┘

  Language accepted:  [+-]? [0-9]+ ( '.' [0-9]+ ([eE][+-]?[0-9]+)? )?
                    | [+-]? [0-9]+   [eE][+-]?[0-9]+
)" << "\n";
}

// ─── Main ─────────────────────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    LexicalAnalyzer la;

    showTransitionDiagram();

    if (argc > 1) {
        // ── CLI mode: classify each argument ─────────────────
        printBanner("CLI Token Classification");
        for (int i = 1; i < argc; ++i) {
            std::string lexeme(argv[i]);
            la.printTrace(lexeme);
            Token tok = la.classify(lexeme);
            std::cout << "  Token → ";
            tok.print();
        }
    } else {
        // ── Default: run test suite + sample traces ───────────
        runTestSuite(la);

        printBanner("FSA Step-by-Step Traces (sample)");
        for (const auto& s : {"42", "-3.14", "2.5E-3", "abc", "1."}) {
            la.printTrace(s);
        }

        // ── Interactive mode ──────────────────────────────────
        printBanner("Interactive Mode  (enter 'exit' to quit)");
        std::string input;
        while (true) {
            std::cout << "\n  Enter token: ";
            if (!(std::cin >> input) || input == "exit") break;
            la.printTrace(input);
            Token tok = la.classify(input);
            std::cout << "  Token → ";
            tok.print();
        }
    }

    return 0;
}
