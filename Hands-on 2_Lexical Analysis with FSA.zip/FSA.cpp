/**
 * @file FSA.cpp
 * @brief Implementation of the Finite State Automaton for numeric validation.
 *
 * Compiladores — CUCEI UdeG  |  Hands-on 2: Lexical Analysis with FSA
 */

#include "FSA.h"
#include <sstream>

// ─── Constructor: build the transition table ─────────────────────────────────
FSA::FSA() {
    _startState = State::Q0;

    // Accept states (final / accepting)
    _acceptStates = { State::Q2, State::Q4, State::Q7 };

    // ── Transitions from Q0 (start) ──────────────────────────────────────────
    _table[{State::Q0, CharClass::SIGN}]  = State::Q1;   // +/- → Q1
    _table[{State::Q0, CharClass::DIGIT}] = State::Q2;   // digit → Q2

    // ── Transitions from Q1 (after sign) ─────────────────────────────────────
    _table[{State::Q1, CharClass::DIGIT}] = State::Q2;   // digit → Q2

    // ── Transitions from Q2 (integer part) ───────────────────────────────────
    _table[{State::Q2, CharClass::DIGIT}] = State::Q2;   // more digits (loop)
    _table[{State::Q2, CharClass::DOT}]   = State::Q3;   // '.' → Q3
    _table[{State::Q2, CharClass::EXP}]   = State::Q5;   // e/E → Q5

    // ── Transitions from Q3 (after dot) ──────────────────────────────────────
    _table[{State::Q3, CharClass::DIGIT}] = State::Q4;   // digit → Q4

    // ── Transitions from Q4 (decimal fraction digits) ─────────────────────────
    _table[{State::Q4, CharClass::DIGIT}] = State::Q4;   // more digits (loop)
    _table[{State::Q4, CharClass::EXP}]   = State::Q5;   // e/E → Q5

    // ── Transitions from Q5 (after exponent marker) ──────────────────────────
    _table[{State::Q5, CharClass::SIGN}]  = State::Q6;   // +/- → Q6
    _table[{State::Q5, CharClass::DIGIT}] = State::Q7;   // digit → Q7

    // ── Transitions from Q6 (after exponent sign) ────────────────────────────
    _table[{State::Q6, CharClass::DIGIT}] = State::Q7;   // digit → Q7

    // ── Transitions from Q7 (exponent digits) ────────────────────────────────
    _table[{State::Q7, CharClass::DIGIT}] = State::Q7;   // more digits (loop)

    // Any undefined transition implicitly goes to DEAD (trap state).
}

// ─── Character classification ─────────────────────────────────────────────────
CharClass FSA::classify(char c) {
    if (c == '+' || c == '-') return CharClass::SIGN;
    if (c >= '0' && c <= '9') return CharClass::DIGIT;
    if (c == '.')              return CharClass::DOT;
    if (c == 'e' || c == 'E') return CharClass::EXP;
    return CharClass::OTHER;
}

// ─── Single transition step ───────────────────────────────────────────────────
State FSA::step(State current, char c) const {
    if (current == State::DEAD) return State::DEAD;
    CharClass cc = classify(c);
    auto it = _table.find({current, cc});
    return (it != _table.end()) ? it->second : State::DEAD;
}

// ─── Validate ─────────────────────────────────────────────────────────────────
bool FSA::validate(const std::string& token) const {
    if (token.empty()) return false;
    State current = _startState;
    for (char c : token) {
        current = step(current, c);
        if (current == State::DEAD) return false;
    }
    return _acceptStates.count(current) > 0;
}

// ─── State name helper ────────────────────────────────────────────────────────
std::string FSA::stateName(State s) {
    switch (s) {
        case State::Q0:   return "q0 (start)";
        case State::Q1:   return "q1 (after sign)";
        case State::Q2:   return "q2 (integer) *";
        case State::Q3:   return "q3 (after dot)";
        case State::Q4:   return "q4 (decimal) *";
        case State::Q5:   return "q5 (after e/E)";
        case State::Q6:   return "q6 (exp sign)";
        case State::Q7:   return "q7 (exponent) *";
        case State::DEAD: return "DEAD";
        default:          return "?";
    }
}

// ─── Trace (step-by-step log) ─────────────────────────────────────────────────
std::vector<std::string> FSA::trace(const std::string& token) const {
    std::vector<std::string> log;
    State current = _startState;

    std::ostringstream ss;
    ss << "  START  → " << stateName(current);
    log.push_back(ss.str());

    for (char c : token) {
        State next = step(current, c);
        std::ostringstream entry;
        entry << "  δ(" << stateName(current) << ", '"
              << c << "') → " << stateName(next);
        log.push_back(entry.str());
        current = next;
        if (current == State::DEAD) break;
    }

    bool accepted = _acceptStates.count(current) > 0;
    log.push_back(accepted ? "  ✓  ACCEPTED" : "  ✗  REJECTED");
    return log;
}
