/**
 * @file LexicalAnalyzer.h
 * @brief Lexical analyzer that uses the FSA to scan and classify numeric tokens.
 *
 * Compiladores — CUCEI UdeG  |  Hands-on 2: Lexical Analysis with FSA
 */

#ifndef LEXICAL_ANALYZER_H
#define LEXICAL_ANALYZER_H

#include "FSA.h"
#include "Token.h"
#include <string>
#include <vector>

class LexicalAnalyzer {
public:
    LexicalAnalyzer();

    /**
     * @brief Classifies a single string as a Token using the FSA.
     */
    Token classify(const std::string& lexeme) const;

    /**
     * @brief Scans a whitespace-separated string and returns all tokens.
     */
    std::vector<Token> scan(const std::string& input) const;

    /**
     * @brief Prints a full trace of the FSA for the given lexeme.
     */
    void printTrace(const std::string& lexeme) const;

private:
    FSA _fsa;

    TokenType inferType(const std::string& lexeme) const;
    std::vector<std::string> split(const std::string& s) const;
};

#endif // LEXICAL_ANALYZER_H
