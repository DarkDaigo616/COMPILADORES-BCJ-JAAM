/**
 * @file LexicalAnalyzer.cpp
 * @brief Implementation of LexicalAnalyzer.
 *
 * Compiladores — CUCEI UdeG  |  Hands-on 2: Lexical Analysis with FSA
 */

#include "LexicalAnalyzer.h"
#include <sstream>
#include <iostream>
#include <algorithm>

LexicalAnalyzer::LexicalAnalyzer() : _fsa() {}

// ─── Infer the specific numeric subtype ──────────────────────────────────────
TokenType LexicalAnalyzer::inferType(const std::string& lexeme) const {
    bool hasDot = (lexeme.find('.') != std::string::npos);
    bool hasExp = (lexeme.find('e') != std::string::npos ||
                   lexeme.find('E') != std::string::npos);

    if (hasExp)      return TokenType::SCIENTIFIC;
    if (hasDot)      return TokenType::DECIMAL;
    return TokenType::INTEGER;
}

// ─── Classify one lexeme ──────────────────────────────────────────────────────
Token LexicalAnalyzer::classify(const std::string& lexeme) const {
    if (_fsa.validate(lexeme)) {
        return Token(inferType(lexeme), lexeme);
    }
    return Token(TokenType::UNKNOWN, lexeme);
}

// ─── Split input string by whitespace ────────────────────────────────────────
std::vector<std::string> LexicalAnalyzer::split(const std::string& s) const {
    std::vector<std::string> tokens;
    std::istringstream iss(s);
    std::string tok;
    while (iss >> tok) tokens.push_back(tok);
    return tokens;
}

// ─── Scan a multi-token input ─────────────────────────────────────────────────
std::vector<Token> LexicalAnalyzer::scan(const std::string& input) const {
    std::vector<Token> result;
    for (const auto& word : split(input)) {
        result.push_back(classify(word));
    }
    return result;
}

// ─── Print FSA trace ──────────────────────────────────────────────────────────
void LexicalAnalyzer::printTrace(const std::string& lexeme) const {
    std::cout << "\n  Tracing FSA for: \"" << lexeme << "\"\n";
    std::cout << "  " << std::string(40, '-') << "\n";
    for (const auto& line : _fsa.trace(lexeme)) {
        std::cout << line << "\n";
    }
    std::cout << "  " << std::string(40, '-') << "\n";
}
