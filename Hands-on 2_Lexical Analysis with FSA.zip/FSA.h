#ifndef FSA_H
#define FSA_H

/**
 * @file FSA.h
 * @brief Finite State Automaton (FSA) for numeric token validation
 *
 * Implements the transition diagram for recognizing valid numeric literals:
 *   - Integers:          42, -7, +100
 *   - Decimals:          3.14, -0.5, +2.71
 *   - Scientific:        1e10, 2.5E-3, -3e+4
 *
 * State diagram:
 *
 *  [q0] --sign--> [q1] --digit--> [q2] --digit--> [q2] (ACCEPT: integer)
 *   |                              |
 *   +--------digit------>[q2]     +--> '.' --> [q3] --digit--> [q4] (ACCEPT: decimal)
 *                                               |
 *                                    [q4] --e/E--> [q5] --sign/digit--> [q6] --digit--> [q7] (ACCEPT: scientific)
 *
 * Compiladores — CUCEI UdeG  |  Hands-on 2: Lexical Analysis with FSA
 */

#include <string>
#include <unordered_map>
#include <set>
#include <vector>

// ─── State Identifiers ───────────────────────────────────────────────────────
enum class State {
    Q0,         // Start
    Q1,         // After sign (+ or -)
    Q2,         // Integer digits          [ACCEPT]
    Q3,         // After decimal point
    Q4,         // Decimal digits          [ACCEPT]
    Q5,         // After 'e' or 'E'
    Q6,         // After exponent sign
    Q7,         // Exponent digits         [ACCEPT]
    DEAD        // Error / trap state
};

// ─── Input Character Categories ──────────────────────────────────────────────
enum class CharClass {
    SIGN,       // '+' or '-'
    DIGIT,      // '0'..'9'
    DOT,        // '.'
    EXP,        // 'e' or 'E'
    OTHER       // anything else → leads to DEAD
};

// ─── Transition Table Entry ──────────────────────────────────────────────────
using TransitionKey = std::pair<State, CharClass>;

struct PairHash {
    std::size_t operator()(const TransitionKey& k) const {
        return std::hash<int>()(static_cast<int>(k.first)) ^
               (std::hash<int>()(static_cast<int>(k.second)) << 4);
    }
};

// ─── FSA Class ───────────────────────────────────────────────────────────────
class FSA {
public:
    FSA();

    /**
     * @brief Validates whether the given string is a valid numeric literal.
     * @param token  The string to evaluate.
     * @return true if accepted, false otherwise.
     */
    bool validate(const std::string& token) const;

    /**
     * @brief Returns the name of a state (for tracing / debugging).
     */
    static std::string stateName(State s);

    /**
     * @brief Runs the automaton step by step and returns a trace log.
     */
    std::vector<std::string> trace(const std::string& token) const;

private:
    std::unordered_map<TransitionKey, State, PairHash> _table;
    std::set<State> _acceptStates;
    State _startState;

    static CharClass classify(char c);
    State step(State current, char c) const;
};

#endif // FSA_H
