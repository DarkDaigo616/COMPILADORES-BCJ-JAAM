/**
 * @file Token.h
 * @brief Token class produced by the lexical analyzer.
 *
 * Compiladores — CUCEI UdeG  |  Hands-on 2: Lexical Analysis with FSA
 */

#ifndef TOKEN_H
#define TOKEN_H

#include <string>
#include <iostream>

// Token types produced by the FSA-based scanner
enum class TokenType {
    INTEGER,        // e.g., 42, -7
    DECIMAL,        // e.g., 3.14, -0.5
    SCIENTIFIC,     // e.g., 1e10, 2.5E-3
    UNKNOWN         // unrecognized / invalid
};

class Token {
public:
    Token(TokenType type, const std::string& lexeme)
        : _type(type), _lexeme(lexeme) {}

    TokenType       type()   const { return _type; }
    const std::string& lexeme() const { return _lexeme; }

    static std::string typeName(TokenType t) {
        switch (t) {
            case TokenType::INTEGER:    return "INTEGER";
            case TokenType::DECIMAL:    return "DECIMAL";
            case TokenType::SCIENTIFIC: return "SCIENTIFIC";
            default:                    return "UNKNOWN";
        }
    }

    void print() const {
        std::cout << "< " << typeName(_type)
                  << " , \"" << _lexeme << "\" >\n";
    }

private:
    TokenType   _type;
    std::string _lexeme;
};

#endif // TOKEN_H
