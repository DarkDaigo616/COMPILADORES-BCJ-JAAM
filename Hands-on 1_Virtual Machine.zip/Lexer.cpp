#include "Lexer.h"
#include <sstream>
#include <algorithm>
#include <cctype>
#include <iostream>

// Known keywords (instruction names)
static const std::vector<std::string> KEYWORDS = {
    "START","STOP","MOVE","ADD","SUB","MUL","DIV","STO","LOAD"
};

// Known register identifiers
static const std::vector<std::string> REGISTERS = {
    "AL","AH","BL","BH","ACC","PC","IR","MAR","MBR"
};

bool Lexer::isKeyword(const std::string& word) {
    std::string upper = word;
    std::transform(upper.begin(), upper.end(), upper.begin(), ::toupper);
    for (const auto& kw : KEYWORDS)
        if (kw == upper) return true;
    return false;
}

bool Lexer::isIdentifier(const std::string& word) {
    std::string upper = word;
    std::transform(upper.begin(), upper.end(), upper.begin(), ::toupper);
    for (const auto& reg : REGISTERS)
        if (reg == upper) return true;
    // Also accept generic identifiers (start with letter, alphanumeric)
    if (word.empty()) return false;
    if (!std::isalpha(word[0])) return false;
    for (char c : word) if (!std::isalnum(c) && c != '_') return false;
    return true;
}

bool Lexer::isDigit(const std::string& word) {
    if (word.empty()) return false;
    size_t start = 0;
    if (word[0] == '-' || word[0] == '+') start = 1;
    if (start >= word.size()) return false;
    for (size_t i = start; i < word.size(); i++)
        if (!std::isdigit(word[i])) return false;
    return true;
}

bool Lexer::isDelimiter(char c) {
    return c == ',' || c == ';' || c == ' ';
}

std::string Lexer::tokenTypeToString(TokenType t) {
    switch (t) {
        case TokenType::KEYWORD:       return "KEYWORD";
        case TokenType::IDENTIFIER:    return "IDENTIFIER";
        case TokenType::DIGIT:         return "DIGIT";
        case TokenType::DELIMITER:     return "DELIMITER";
        default:                       return "UNKNOWN";
    }
}

std::vector<Token> Lexer::tokenize(const std::string& line) {
    std::vector<Token> tokens;
    std::string word;
    std::istringstream stream(line);

    // Split by spaces and commas
    std::string token_str;
    std::string clean;
    // Replace commas/semicolons with spaces for easier splitting
    for (char c : line) {
        if (c == ',' || c == ';') clean += ' ';
        else clean += c;
    }

    std::istringstream ss(clean);
    while (ss >> word) {
        Token tok;
        tok.value = word;
        std::string upper = word;
        std::transform(upper.begin(), upper.end(), upper.begin(), ::toupper);

        if (isKeyword(upper)) {
            tok.type = TokenType::KEYWORD;
            tok.value = upper; // normalize to uppercase
        } else if (isDigit(word)) {
            tok.type = TokenType::DIGIT;
        } else if (isIdentifier(upper)) {
            tok.type = TokenType::IDENTIFIER;
            tok.value = upper; // normalize registers to uppercase
        } else {
            tok.type = TokenType::UNKNOWN_TOKEN;
        }
        tokens.push_back(tok);
    }
    return tokens;
}

Instruction* Lexer::parse(const std::string& line) {
    auto tokens = tokenize(line);
    if (tokens.empty()) return nullptr;

    // First token must be a keyword
    if (tokens[0].type != TokenType::KEYWORD) {
        std::cerr << "[Lexer] ERROR: First token is not a keyword: " << tokens[0].value << "\n";
        return nullptr;
    }

    std::string instrName = tokens[0].value;
    InstructionType type = Instruction::parseType(instrName);

    std::vector<std::string> args;
    for (size_t i = 1; i < tokens.size(); i++) {
        if (tokens[i].type == TokenType::KEYWORD ||
            tokens[i].type == TokenType::IDENTIFIER ||
            tokens[i].type == TokenType::DIGIT) {
            args.push_back(tokens[i].value);
        }
    }

    return new Instruction(instrName, args, type);
}
