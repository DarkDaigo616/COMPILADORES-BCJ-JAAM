#include "ControlUnit.h"
#include <iostream>
#include <iomanip>
#include <stdexcept>

ControlUnit::ControlUnit(Registers& regs, Memory& mem)
    : registers(regs), memory(mem), running(false) {}

void ControlUnit::printSeparator(const std::string& label) const {
    std::cout << "\n╔══════════════════════════════════════╗\n";
    std::cout << "║  " << std::left << std::setw(36) << label << "║\n";
    std::cout << "╚══════════════════════════════════════╝\n";
}

void ControlUnit::printState(const std::string& stage) const {
    std::cout << "  ─── " << stage << " ───\n";
    registers.print();
}

// ── FETCH ────────────────────────────────────────────────────────────────────
// MAR ← PC ; MBR ← Memory[MAR] ; IR ← MBR ; PC ← PC + 1
void ControlUnit::fetch() {
    int pc = registers.getPC();
    registers.setMAR(pc);
    std::string instrLine = memory.fetch(pc);
    registers.setMBR(pc);   // MBR holds the address of the fetched instruction
    registers.setIR(instrLine);
    registers.setPC(pc + 1);
}

// ── DECODE ───────────────────────────────────────────────────────────────────
// Use the Lexer (Lexical Analyzer) to decode the instruction in IR
Instruction* ControlUnit::decode() {
    std::string ir = registers.getIR();
    Instruction* instr = lexer.parse(ir);

    // Print token analysis during decode
    std::cout << "  [Lexer] Tokenizing: \"" << ir << "\"\n";
    auto tokens = lexer.tokenize(ir);
    for (const auto& tok : tokens) {
        std::cout << "    TOKEN -> type=" << Lexer::tokenTypeToString(tok.type)
                  << "  value=\"" << tok.value << "\"\n";
    }
    return instr;
}

// ── EXECUTE ──────────────────────────────────────────────────────────────────
void ControlUnit::execute(Instruction* instr) {
    if (!instr) {
        std::cerr << "  [Execute] ERROR: null instruction\n";
        running = false;
        return;
    }

    std::cout << "  [Execute] " << Instruction::typeToString(instr->getInterpretation())
              << " (" << instr->toString() << ")\n";

    switch (instr->getInterpretation()) {

    case InstructionType::START:
        running = true;
        std::cout << "  >> Program started.\n";
        break;

    case InstructionType::STOP:
        running = false;
        std::cout << "  >> Program stopped. ACC = " << registers.getACC() << "\n";
        break;

    // MOVE reg addr  → load Memory[addr] into register reg
    case InstructionType::MOVE: {
        if (instr->getLength() < 2) { std::cerr << "  MOVE needs 2 args\n"; break; }
        std::string reg  = instr->getArgument(0);
        std::string addr = instr->getArgument(1);
        int address = std::stoi(addr);
        registers.setMAR(address);
        int value = memory.loadData(address);
        registers.setMBR(value);
        registers.setRegisterValue(reg, value);
        std::cout << "  >> " << reg << " ← Memory[" << address << "] = " << value << "\n";
        break;
    }

    // ADD reg1 reg2  → ACC = reg1 + reg2
    case InstructionType::ADD: {
        if (instr->getLength() < 2) { std::cerr << "  ADD needs 2 args\n"; break; }
        int v1 = registers.getRegisterValue(instr->getArgument(0));
        int v2 = registers.getRegisterValue(instr->getArgument(1));
        registers.setACC(v1 + v2);
        std::cout << "  >> ACC = " << instr->getArgument(0) << "(" << v1 << ") + "
                  << instr->getArgument(1) << "(" << v2 << ") = " << (v1+v2) << "\n";
        break;
    }

    // SUB reg1 reg2  → ACC = reg1 - reg2
    case InstructionType::SUB: {
        if (instr->getLength() < 2) { std::cerr << "  SUB needs 2 args\n"; break; }
        int v1 = registers.getRegisterValue(instr->getArgument(0));
        int v2 = registers.getRegisterValue(instr->getArgument(1));
        registers.setACC(v1 - v2);
        std::cout << "  >> ACC = " << instr->getArgument(0) << "(" << v1 << ") - "
                  << instr->getArgument(1) << "(" << v2 << ") = " << (v1-v2) << "\n";
        break;
    }

    // MUL reg1 reg2  → ACC = reg1 * reg2
    case InstructionType::MUL: {
        if (instr->getLength() < 2) { std::cerr << "  MUL needs 2 args\n"; break; }
        int v1 = registers.getRegisterValue(instr->getArgument(0));
        int v2 = registers.getRegisterValue(instr->getArgument(1));
        registers.setACC(v1 * v2);
        std::cout << "  >> ACC = " << instr->getArgument(0) << "(" << v1 << ") * "
                  << instr->getArgument(1) << "(" << v2 << ") = " << (v1*v2) << "\n";
        break;
    }

    // DIV reg1 reg2  → ACC = reg1 / reg2
    case InstructionType::DIV: {
        if (instr->getLength() < 2) { std::cerr << "  DIV needs 2 args\n"; break; }
        int v1 = registers.getRegisterValue(instr->getArgument(0));
        int v2 = registers.getRegisterValue(instr->getArgument(1));
        if (v2 == 0) { std::cerr << "  DIV ERROR: division by zero\n"; break; }
        registers.setACC(v1 / v2);
        std::cout << "  >> ACC = " << instr->getArgument(0) << "(" << v1 << ") / "
                  << instr->getArgument(1) << "(" << v2 << ") = " << (v1/v2) << "\n";
        break;
    }

    // STO addr  → Memory[addr] = ACC
    case InstructionType::STO: {
        if (instr->getLength() < 1) { std::cerr << "  STO needs 1 arg\n"; break; }
        int address = std::stoi(instr->getArgument(0));
        registers.setMAR(address);
        int acc = registers.getACC();
        registers.setMBR(acc);
        memory.storeData(address, acc);
        std::cout << "  >> Memory[" << address << "] ← ACC = " << acc << "\n";
        break;
    }

    // LOAD addr  → ACC = Memory[addr]
    case InstructionType::LOAD: {
        if (instr->getLength() < 1) { std::cerr << "  LOAD needs 1 arg\n"; break; }
        int address = std::stoi(instr->getArgument(0));
        registers.setMAR(address);
        int value = memory.loadData(address);
        registers.setMBR(value);
        registers.setACC(value);
        std::cout << "  >> ACC ← Memory[" << address << "] = " << value << "\n";
        break;
    }

    default:
        std::cerr << "  [Execute] Unknown instruction: " << instr->toString() << "\n";
        break;
    }

    delete instr;
}

// ── MACHINE CYCLE ────────────────────────────────────────────────────────────
void ControlUnit::run() {
    running = true;
    int cycle = 0;

    while (running && registers.getPC() < memory.getSize()) {
        cycle++;
        std::cout << "\n━━━━━━━━━━  MACHINE CYCLE #" << cycle << "  ━━━━━━━━━━\n";

        // ── FETCH
        printSeparator("FETCH");
        fetch();
        printState("After FETCH");

        // Skip empty memory slots
        if (registers.getIR().empty()) {
            std::cout << "  [Empty slot - skipping]\n";
            continue;
        }

        // ── DECODE
        printSeparator("DECODE");
        Instruction* instr = decode();
        printState("After DECODE");

        // ── EXECUTE
        printSeparator("EXECUTE");
        execute(instr);
        printState("After EXECUTE");

        if (!running) break;
    }

    std::cout << "\n══════════════════════════════════════════\n";
    std::cout << "  Virtual Machine finished.\n";
    std::cout << "  Final ACC = " << registers.getACC() << "\n";
    std::cout << "══════════════════════════════════════════\n";
}
