#include "VirtualMachine.h"
#include <iostream>
#include <string>

// ─── Demo Program 1: Addition ──────────────────────────────────────────────
// Data: Memory[100]=15, Memory[101]=27
// Program: load both into AL, BL → ADD AL BL → STO result → STOP
void runDemo1() {
    std::cout << "\n";
    std::cout << "████████████████████████████████████████████\n";
    std::cout << "  DEMO 1: Addition  (15 + 27)\n";
    std::cout << "████████████████████████████████████████████\n";

    VirtualMachine vm;
    vm.initData(100, 15);   // Memory[100] = 15
    vm.initData(101, 27);   // Memory[101] = 27

    std::vector<std::string> program = {
        "START",
        "MOVE AL 100",    // AL ← Memory[100] = 15
        "MOVE BL 101",    // BL ← Memory[101] = 27
        "ADD AL BL",      // ACC = AL + BL = 42
        "STO 200",        // Memory[200] ← ACC = 42
        "STOP"
    };

    vm.run(program);
}

// ─── Demo Program 2: Mixed Arithmetic ────────────────────────────────────────
// Data: Memory[100]=50, Memory[101]=8
// Program: (50 - 8) * 2 → result stored
void runDemo2() {
    std::cout << "\n";
    std::cout << "████████████████████████████████████████████\n";
    std::cout << "  DEMO 2: Mixed Arithmetic  ((50 - 8) * 2)\n";
    std::cout << "████████████████████████████████████████████\n";

    VirtualMachine vm;
    vm.initData(100, 50);   // Memory[100] = 50
    vm.initData(101, 8);    // Memory[101] = 8
    vm.initData(102, 2);    // Memory[102] = 2

    std::vector<std::string> program = {
        "START",
        "MOVE AL 100",    // AL ← 50
        "MOVE BL 101",    // BL ← 8
        "SUB AL BL",      // ACC = 50 - 8 = 42
        "STO 200",        // Memory[200] ← 42
        "MOVE AH 200",    // AH ← Memory[200] = 42
        "MOVE BH 102",    // BH ← Memory[102] = 2
        "MUL AH BH",      // ACC = 42 * 2 = 84
        "STO 201",        // Memory[201] ← 84
        "STOP"
    };

    vm.run(program);
}

// ─── Main ─────────────────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    std::cout << "╔══════════════════════════════════════════╗\n";
    std::cout << "║     Virtual Machine - Compiladores       ║\n";
    std::cout << "║     OO Implementation in C++             ║\n";
    std::cout << "╚══════════════════════════════════════════╝\n";

    if (argc > 1) {
        // Run from file if a filename is provided
        std::string filename = argv[1];
        std::cout << "\nLoading program from file: " << filename << "\n";
        VirtualMachine vm;
        vm.runFromFile(filename);
    } else {
        // Run built-in demos
        runDemo1();
        runDemo2();
    }

    return 0;
}
