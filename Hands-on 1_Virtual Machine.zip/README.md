# Hands-on 1: Virtual Machine
### Compiladores 2026A — CUCEI, UdeG

Implementación orientada a objetos en **C++17** de una Máquina Virtual con Ciclo Máquina completo (Fetch → Decode → Execute).

---

## Arquitectura del Sistema

```
┌─────────────────────────────────────────────────┐
│                 VirtualMachine                  │
│  ┌─────────────┐  ┌──────────┐  ┌───────────┐  │
│  │ProgramLoader│  │  Memory  │  │ Registers │  │
│  └─────────────┘  └──────────┘  └───────────┘  │
│  ┌─────────────────────────────────────────┐    │
│  │           ControlUnit                   │    │
│  │  Fetch → Decode (Lexer) → Execute       │    │
│  └─────────────────────────────────────────┘    │
└─────────────────────────────────────────────────┘
```

## Clases

| Clase | Responsabilidad |
|---|---|
| `Instruction` | Modela una instrucción: nombre, argumentos, interpretación, longitud |
| `Lexer` | Analizador léxico: tokeniza y parsea líneas de instrucciones |
| `Memory` | Memoria principal (instrucciones y datos) |
| `Registers` | Registros de propósito general (AL, AH, BL, BH) y específico (PC, IR, MAR, MBR, ACC) |
| `ControlUnit` | Unidad de Control: ejecuta el Ciclo Máquina |
| `ProgramLoader` | Carga el programa en memoria |
| `VirtualMachine` | Fachada que integra todos los componentes |

## Instruction Set

| Instrucción | Argumentos | Descripción |
|---|---|---|
| `START` | — | Inicio del programa |
| `STOP` | — | Fin del programa |
| `MOVE reg addr` | reg, addr | Carga Memory[addr] en el registro `reg` |
| `ADD reg1 reg2` | reg1, reg2 | ACC = reg1 + reg2 |
| `SUB reg1 reg2` | reg1, reg2 | ACC = reg1 − reg2 |
| `MUL reg1 reg2` | reg1, reg2 | ACC = reg1 × reg2 |
| `DIV reg1 reg2` | reg1, reg2 | ACC = reg1 ÷ reg2 |
| `STO addr` | addr | Memory[addr] = ACC |
| `LOAD addr` | addr | ACC = Memory[addr] |

## Registros

**Propósito Específico:** `PC` (Program Counter), `IR` (Instruction Register), `MAR` (Memory Address Register), `MBR` (Memory Buffer Register), `ACC` (Acumulador)

**Propósito General:** `AL`, `AH`, `BL`, `BH`

## Tokens Reconocidos (Lexer)

| Tipo | Ejemplos |
|---|---|
| `KEYWORD` | START, STOP, MOVE, ADD, SUB, MUL, DIV, STO, LOAD |
| `IDENTIFIER` | AL, AH, BL, BH, ACC, PC, IR, MAR, MBR |
| `DIGIT` | 0, 100, -5, 200 |
| `DELIMITER` | `,` `;` ` ` |

## Compilar y Ejecutar

```bash
# Compilar
make

# Ejecutar demos integrados
./vm

# Ejecutar un programa desde archivo
./vm sample_program.txt
```

### Requisitos
- g++ con soporte C++17
- GNU Make

## Ciclo Máquina

Cada instrucción pasa por tres etapas:

1. **FETCH** — `MAR ← PC` ; `IR ← Memory[MAR]` ; `PC ← PC + 1`
2. **DECODE** — El Lexer tokeniza la cadena en IR e identifica KEYWORD, IDENTIFIER, DIGIT
3. **EXECUTE** — La Unidad de Control ejecuta la acción correspondiente al token KEYWORD

## Demos Incluidos

**Demo 1 — Suma:** `15 + 27 = 42`
```
START
MOVE AL 100    ; AL ← 15
MOVE BL 101    ; BL ← 27
ADD AL BL      ; ACC = 42
STO 200        ; Memory[200] ← 42
STOP
```

**Demo 2 — Aritmética mixta:** `(50 − 8) × 2 = 84`
```
START
MOVE AL 100    ; AL ← 50
MOVE BL 101    ; BL ← 8
SUB AL BL      ; ACC = 42
STO 200
MOVE AH 200    ; AH ← 42
MOVE BH 102    ; BH ← 2
MUL AH BH      ; ACC = 84
STO 201
STOP
```

## Estructura del Repositorio

```
virtual-machine/
├── Instruction.h / .cpp    # Modelo de instrucción
├── Lexer.h / .cpp          # Analizador léxico
├── Memory.h / .cpp         # Memoria principal
├── Registers.h / .cpp      # Registros del procesador
├── ControlUnit.h / .cpp    # Unidad de Control + Ciclo Máquina
├── ProgramLoader.h / .cpp  # Cargador de programa
├── VirtualMachine.h / .cpp # Fachada del sistema
├── main.cpp                # Punto de entrada y demos
├── sample_program.txt      # Programa de ejemplo externo
├── Makefile
└── README.md
```
