%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ============================================================
   TABLA DE SÍMBOLOS
   ============================================================ */
#define MAX_SYMBOLS 256

typedef struct {
    char nombre[64];
    char clase[16];    /* "variable", "funcion", "macro" */
    char tipo[16];     /* "int", etc. */
    int  ambito;
    int  aridad;
    int  activo;
    int  usado;        /* NUEVO: 1 si fue usada */
} Simbolo;

Simbolo tabla[MAX_SYMBOLS];
int num_simbolos = 0;
int ambito_actual = 0;
int errores_semanticos = 0;

extern int yylineno;
extern int yylex();
void yyerror(const char *s);

/* ---- prototipos ---- */
int  buscar_simbolo(const char *nombre, int solo_activo);
int  buscar_en_ambito(const char *nombre, int ambito);
void declarar_variable(const char *nombre, const char *tipo);
void declarar_funcion(const char *nombre, int aridad);
void declarar_macro(const char *nombre);
void usar_variable(const char *nombre);
void verificar_llamada(const char *nombre, int args_dados);
void imprimir_tabla();
void cerrar_ambito();

/* ---- implementaciones ---- */

int buscar_simbolo(const char *nombre, int solo_activo) {
    for (int i = 0; i < num_simbolos; i++) {
        if (strcmp(tabla[i].nombre, nombre) == 0) {
            if (!solo_activo || tabla[i].activo) return i;
        }
    }
    return -1;
}

int buscar_en_ambito(const char *nombre, int ambito) {
    for (int i = 0; i < num_simbolos; i++) {
        if (strcmp(tabla[i].nombre, nombre) == 0 &&
            tabla[i].ambito == ambito && tabla[i].activo)
            return i;
    }
    return -1;
}

void declarar_variable(const char *nombre, const char *tipo) {
    int idx = buscar_en_ambito(nombre, ambito_actual);
    if (idx >= 0) {
        fprintf(stderr, "Error semántico en línea %d: redeclaración de variable '%s'\n",
                yylineno, nombre);
        errores_semanticos++;
        return;
    }
    if (num_simbolos >= MAX_SYMBOLS) { fprintf(stderr, "Tabla llena\n"); return; }
    strcpy(tabla[num_simbolos].nombre, nombre);
    strcpy(tabla[num_simbolos].clase,  "variable");
    strcpy(tabla[num_simbolos].tipo,   tipo);
    tabla[num_simbolos].ambito  = ambito_actual;
    tabla[num_simbolos].aridad  = -1;
    tabla[num_simbolos].activo  = 1;
    tabla[num_simbolos].usado   = 0;
    num_simbolos++;
}

void declarar_funcion(const char *nombre, int aridad) {
    int idx = buscar_simbolo(nombre, 0);
    if (idx >= 0 && strcmp(tabla[idx].clase, "funcion") == 0) {
        fprintf(stderr, "Error semántico en línea %d: función '%s' ya declarada\n",
                yylineno, nombre);
        errores_semanticos++;
        return;
    }
    if (num_simbolos >= MAX_SYMBOLS) return;
    strcpy(tabla[num_simbolos].nombre, nombre);
    strcpy(tabla[num_simbolos].clase,  "funcion");
    strcpy(tabla[num_simbolos].tipo,   "int");
    tabla[num_simbolos].ambito  = 0;
    tabla[num_simbolos].aridad  = aridad;
    tabla[num_simbolos].activo  = 1;
    tabla[num_simbolos].usado   = 1;
    num_simbolos++;
}

void declarar_macro(const char *nombre) {
    int idx = buscar_simbolo(nombre, 0);
    if (idx >= 0 && strcmp(tabla[idx].clase, "macro") == 0) {
        fprintf(stderr, "Error semántico en línea %d: macro '%s' ya definida\n",
                yylineno, nombre);
        errores_semanticos++;
        return;
    }
    if (num_simbolos >= MAX_SYMBOLS) return;
    strcpy(tabla[num_simbolos].nombre, nombre);
    strcpy(tabla[num_simbolos].clase,  "macro");
    strcpy(tabla[num_simbolos].tipo,   "int");
    tabla[num_simbolos].ambito  = 0;
    tabla[num_simbolos].aridad  = -1;
    tabla[num_simbolos].activo  = 1;
    tabla[num_simbolos].usado   = 1;
    num_simbolos++;
}

void usar_variable(const char *nombre) {
    /* buscar en ámbitoS activos de mayor a menor */
    for (int a = ambito_actual; a >= 0; a--) {
        int idx = buscar_en_ambito(nombre, a);
        if (idx >= 0) {
            tabla[idx].usado = 1;
            return;
        }
    }
    /* también puede ser macro */
    int idx = buscar_simbolo(nombre, 1);
    if (idx >= 0) { tabla[idx].usado = 1; return; }

    fprintf(stderr, "Error semántico en línea %d: variable '%s' no declarada\n",
            yylineno, nombre);
    errores_semanticos++;
}

void verificar_llamada(const char *nombre, int args_dados) {
    int idx = buscar_simbolo(nombre, 1);
    if (idx < 0 || strcmp(tabla[idx].clase, "funcion") != 0) {
        fprintf(stderr, "Error semántico en línea %d: función '%s' no declarada\n",
                yylineno, nombre);
        errores_semanticos++;
        return;
    }
    tabla[idx].usado = 1;
    if (tabla[idx].aridad != args_dados && tabla[idx].aridad >= 0) {
        fprintf(stderr,
            "Error semántico en línea %d: función '%s' espera %d argumento(s), pero recibió %d\n",
            yylineno, nombre, tabla[idx].aridad, args_dados);
        errores_semanticos++;
    }
}

void cerrar_ambito() {
    /* marcar advertencias de no-usadas en el ámbito que se cierra */
    for (int i = 0; i < num_simbolos; i++) {
        if (tabla[i].ambito == ambito_actual &&
            tabla[i].activo &&
            strcmp(tabla[i].clase, "variable") == 0 &&
            tabla[i].usado == 0) {
            fprintf(stderr, "Advertencia: variable '%s' declarada pero no usada\n",
                    tabla[i].nombre);
        }
        if (tabla[i].ambito == ambito_actual) tabla[i].activo = 0;
    }
    ambito_actual--;
}

void imprimir_tabla() {
    printf("\n+----------------+----------+--------+--------+--------+\n");
    printf("| %-14s | %-8s | %-6s | %-6s | %-6s |\n",
           "Nombre","Clase","Tipo","Ámbito","Aridad");
    printf("+----------------+----------+--------+--------+--------+\n");
    for (int i = 0; i < num_simbolos; i++) {
        char aridad_str[8];
        if (tabla[i].aridad < 0) strcpy(aridad_str, "-");
        else snprintf(aridad_str, sizeof(aridad_str), "%d", tabla[i].aridad);
        printf("| %-14s | %-8s | %-6s | %-6d | %-6s |\n",
               tabla[i].nombre, tabla[i].clase, tabla[i].tipo,
               tabla[i].ambito, aridad_str);
    }
    printf("+----------------+----------+--------+--------+--------+\n");
}
%}

%union {
    char *str;
    int   ival;
}

%token <str> ID NUM STRING
%token INCLUDE DEFINE INT FUNC RETURN IF
%token PLUS MINUS TIMES DIVIDE
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON COMMA ASSIGN LT GT DOT

%type <ival> param_list arg_list

%%

programa
    : preprocesador declaraciones
    ;

/* ============ PREPROCESADOR ============ */
preprocesador
    : preprocesador directiva
    |
    ;

directiva
    : INCLUDE STRING SEMICOLON
    | INCLUDE LT ID GT            /* #include <stdio.h> sin comillas */
    | DEFINE ID NUM               { declarar_macro($2); free($2); free($3); }
    | DEFINE ID ID                { declarar_macro($2); free($2); free($3); }
    ;

/* ============ DECLARACIONES GLOBALES ============ */
declaraciones
    : declaraciones decl_global
    |
    ;

decl_global
    : INT ID SEMICOLON            { declarar_variable($2, "int"); free($2); }
    | funcion
    ;

/* ============ FUNCIONES ============ */
funcion
    : FUNC ID LPAREN              { ambito_actual++; }
      param_list RPAREN           { declarar_funcion($2, $5); free($2); }
      LBRACE cuerpo RBRACE        { cerrar_ambito(); }
    ;

param_list
    : ID                          { declarar_variable($1, "int"); free($1); $$ = 1; }
    | param_list COMMA ID         { declarar_variable($3, "int"); free($3); $$ = $1 + 1; }
    |                             { $$ = 0; }
    ;

/* ============ CUERPO / SENTENCIAS ============ */
cuerpo
    : cuerpo sentencia
    |
    ;

sentencia
    : INT ID SEMICOLON            { declarar_variable($2, "int"); free($2); }
    | ID ASSIGN expr SEMICOLON    { usar_variable($1); free($1); }
    | ID LPAREN arg_list RPAREN SEMICOLON
                                  { verificar_llamada($1, $3); free($1); }
    | RETURN expr SEMICOLON
    | sentencia_if
    ;

sentencia_if
    : IF LPAREN ID RPAREN         { usar_variable($3); free($3); ambito_actual++; }
      LBRACE cuerpo RBRACE        { cerrar_ambito(); }
    ;

/* ============ EXPRESIONES ============ */
expr
    : term
    | expr PLUS  term
    | expr MINUS term
    ;

term
    : factor
    | term TIMES  factor
    | term DIVIDE factor
    ;

factor
    : ID                          { usar_variable($1); free($1); }
    | NUM                         { free($1); }
    | LPAREN expr RPAREN
    ;

/* ============ ARGUMENTOS ============ */
arg_list
    : arg                         { $$ = 1; }
    | arg_list COMMA arg          { $$ = $1 + 1; }
    |                             { $$ = 0; }
    ;

arg
    : ID                          { usar_variable($1); free($1); }
    | NUM                         { free($1); }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Error sintáctico en línea %d: %s\n", yylineno, s);
}

int main(int argc, char *argv[]) {
    extern FILE *yyin;
    if (argc < 2) {
        fprintf(stderr, "Uso: %s <archivo.c>\n", argv[0]);
        return 1;
    }
    yyin = fopen(argv[1], "r");
    if (!yyin) {
        perror("No se pudo abrir el archivo");
        return 1;
    }
    yyparse();
    fclose(yyin);

    imprimir_tabla();

    if (errores_semanticos > 0)
        printf("\nAnálisis terminado con %d error(es) semántico(s).\n", errores_semanticos);
    else
        printf("\nAnálisis completado sin errores semánticos.\n");

    return 0;
}
